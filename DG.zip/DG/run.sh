#!/usr/bin/env bash


path="${0%/*}"


echo $path

php $path"/dir2json.php" $path"/arbo" $path"/json.json" "JSON_UNESCAPED_UNICODE"


