
var Reportage = function(options){
    var commanditaire ;
    var reporter ;
    var debut ;
    var fin ;
    var fr ;
    var en ;
    var es ;
    var rootReportage = this;
    var intermediaire = new Array();
    var terminal = new Array();
};

var Intermediaire = function(options){
    var id;
    var nom ;
    var description ;
    var rootIntermediaire = this;
    var intermediaire = new Array();
    var terminal = new Array();
};

var Terminal = function(options){
    var id;
    var nom ;
    var diffusion ;
    var remarquable ;
    var personnes ;
    var fr ;
    var en ;
    var es ;
    var rootTerminal = this;
    var fichiers = new Array();
};
