/* --- internationalisation des messages du code JS --- */
/* tableau des clés des messages du code JS */
var t_msg_js = new Array(); 

/*
t_msg_js['msg_js_cet_elem_existe_deja_dans_rep'] = "Cet élément existe déjà dans le répertoire. TXT PROVISOIREE";
t_msg_js['msg_js_2'] = "Cet élément 2222222 existe déjà dans le répertoire. TXT PROVISOIRE";
*/
/**/
t_msg_js = {
  "msg_js_cet_elem_existe_deja_dans_rep" : "Un élément de même nom existe déjà dans le répertoire.",
  "msg_js_confirm_supprimer_contenu_de_cet_element" : "Attention ! êtes-vous sûr de vouloir supprimer le contenu de cet élément ? TXT PROVISOIRE",
};
/**/
